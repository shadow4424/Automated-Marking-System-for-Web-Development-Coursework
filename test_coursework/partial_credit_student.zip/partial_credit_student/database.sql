-- Partial Credit Student - Database Schema
-- Has attempt at proper structure but contains errors

-- Create database (shows understanding)
CREATE DATABASE portfolio_db;

USE portfolio_db;

-- Users table (missing proper constraints)
CREATE TABLE users (
    id INT,  -- ERROR: Missing PRIMARY KEY and AUTO_INCREMENT
    username VARCHAR(50),
    email VARCHAR(100),
    password VARCHAR(50),  -- ERROR: Should be password_hash, too short
    created_at DATETIME
    -- ERROR: Missing closing parenthesis and semicolon

-- Messages table (shows clear attempt)
CREATE TABLE messages (
    id INT PRIMARY KEY AUTO_INCREMENT
    name VARCHAR(100),  -- ERROR: Missing comma after AUTO_INCREMENT
    email VARCHAR(100),
    message TEXT,
    created_at TIMESTAMP
);

-- Attempt at inserting data
INSERT INTO users VALUES (1, 'student', 'test@test.com', 'password123', NOW());

-- Query attempt (shows understanding of SELECT)
SELECT * FROM messages WHERE email = 'test@test.com';

-- Join attempt (syntax error)
SELECT users.username, messages.message 
FROM users 
JOIN messages WHERE users.id = messages.user_id;  -- ERROR: Should use ON not WHERE
