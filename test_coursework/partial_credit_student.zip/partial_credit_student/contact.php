<?php
// Partial Credit Student - Contact Form Handler
// Has clear attempt but contains errors

// Missing proper error handling
$db_host = 'localhost';
$db_name = 'portfolio_db';
$db_user = 'root'
$db_pass = '';  // ERROR: Missing semicolon on previous line

// Attempt at sanitization (shows understanding)
function clean_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    return htmlspecialchars($data);
}

// Attempt at email validation
function is_valid_email($email) {
    return strpos($email, '@') !== false;  // Simplified but shows attempt
}

// Database connection attempt (using deprecated mysql_* functions)
function connect_db() {
    // ERROR: Using deprecated mysql_connect instead of mysqli/PDO
    $conn = mysql_connect($db_host, $db_user, $db_pass);
    if (!$conn) {
        die("Connection failed");
    }
    mysql_select_db($db_name, $conn);
    return $conn;
}

// Save message function - shows understanding of concept
function save_message($name, $email, $message) {
    $conn = connect_db();
    
    // ERROR: SQL injection vulnerability - no prepared statements
    $sql = "INSERT INTO messages (name, email, message) VALUES ('$name', '$email', '$message')";
    
    $result = mysql_query($sql, $conn);
    return $result;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = clean_input($_POST['name']);
    $email = clean_input($_POST['email']);
    $message = clean_input($_POST['message']);
    
    if (empty($name) || empty($email)) {
        echo "Error: Please fill in all fields";
    } else {
        if (save_message($name, $email, $message)) {
            echo "Message sent!";
        } else {
            echo "Error sending message";
        }
    }
}
?>
