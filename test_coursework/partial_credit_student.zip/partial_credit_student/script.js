// Partial Credit Student - Has calculateTotal function but syntax error

// ERROR: Typo that breaks parsing
var x = ;

// This function shows the student attempted the required functionality
function calculateTotal(items, taxRate) {
    var total = 0;

    // Loop through items
    for (var i = 0; i < items.length; i++) {
        total = total + items[i];
    }

    // Add tax
    var tax = total * taxRate;
    total = total + tax;

    return total;
}

// Form validation attempt
function validateForm() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;

    if (name == '' || email == '') {
        alert('Please fill in all fields');
        return false;
    }

    return true;
}

// Event listener attempt
document.addEventListener('DOMContentLoaded', function () {
    console.log('Page loaded');
});
