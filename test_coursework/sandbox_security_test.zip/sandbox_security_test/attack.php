<?php
/**
 * SECURITY TEST: Attempt to read /etc/passwd
 * 
 * If the sandbox is working:
 * - File_get_contents should fail with "Permission denied" or similar
 * - The host machine's password hashes should NOT be readable
 */

echo "<h1>Test 1: Reading /etc/passwd</h1>";
echo "<p>Attempting to read host machine's password file...</p>";

try {
    $content = file_get_contents('/etc/passwd');
    if ($content === false) {
        echo "<p style='color: green;'><strong>✓ SAFE:</strong> File read attempt failed (Permission Denied)</p>";
    } else {
        echo "<p style='color: red;'><strong>✗ BREACH:</strong> Successfully read /etc/passwd!</p>";
        echo "<pre>" . htmlspecialchars($content) . "</pre>";
    }
} catch (Exception $e) {
    echo "<p style='color: green;'><strong>✓ SAFE:</strong> Exception caught: " . $e->getMessage() . "</p>";
}

// Also try multiple known host files
$hostFiles = [
    '/etc/shadow',    // Root's password file
    '/root/.ssh/id_rsa',  // SSH private key
    '/etc/sudoers',   // Sudoers file
    '/proc/1/environ',    // Host process environment
];

echo "<h2>Additional Target Files</h2>";
foreach ($hostFiles as $file) {
    $readable = is_readable($file);
    if ($readable) {
        echo "<p style='color: red;'><strong>✗ BREACH:</strong> $file is readable!</p>";
    } else {
        echo "<p style='color: green;'><strong>✓ SAFE:</strong> $file is not accessible</p>";
    }
}
?>
