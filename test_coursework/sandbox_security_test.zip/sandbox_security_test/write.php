<?php
/**
 * SECURITY TEST: Attempt to write files on host
 * 
 * If the sandbox is working:
 * - Should only be able to write within submission directory
 * - Should NOT be able to write to host filesystem
 */

echo "<h1>Test 6: File Write Attempts</h1>";

// Test 1: Write in submission directory (should work)
echo "<h2>Write within submission directory (SHOULD SUCCEED)</h2>";
$local_file = 'test_write_local.txt';
$result = file_put_contents($local_file, 'Test file written from PHP. Timestamp: ' . date('Y-m-d H:i:s'));
if ($result !== false) {
    echo "<p style='color: green;'><strong>✓ Expected:</strong> Successfully wrote $local_file (size: $result bytes)</p>";
} else {
    echo "<p style='color: red;'><strong>✗ Unexpected:</strong> Failed to write $local_file</p>";
}

// Test 2: Try to write to parent directory (SHOULD FAIL)
echo "<h2>Write to parent directory (SHOULD FAIL)</h2>";
$parent_file = '../parent_write_test.txt';
$result = @file_put_contents($parent_file, 'Malicious parent directory write');
if ($result !== false) {
    echo "<p style='color: red;'><strong>✗ BREACH:</strong> Successfully wrote to parent directory!</p>";
} else {
    echo "<p style='color: green;'><strong>✓ SAFE:</strong> Parent directory write blocked</p>";
}

// Test 3: Try to write to host root (SHOULD FAIL)
echo "<h2>Write to host filesystem (SHOULD FAIL)</h2>";
$host_files = [
    '/tmp/ams_breach.txt',
    '/var/www/html/breach.txt',
    '/root/breach.txt',
    '/etc/ams_breach.txt',
];

foreach ($host_files as $file) {
    $result = @file_put_contents($file, 'Student malicious payload');
    if ($result !== false) {
        echo "<p style='color: red;'><strong>✗ BREACH:</strong> Successfully wrote to $file!</p>";
    } else {
        echo "<p style='color: green;'><strong>✓ SAFE:</strong> Cannot write to $file</p>";
    }
}

// Test 4: Try mkdir attacks
echo "<h2>Directory Creation Attacks (SHOULD FAIL)</h2>";
$dirs = [
    '../malicious',
    '/tmp/ams_attack_dir',
    '/malicious_dir',
];

foreach ($dirs as $dir) {
    $result = @mkdir($dir, 0777, true);
    if ($result) {
        echo "<p style='color: red;'><strong>✗ BREACH:</strong> Successfully created directory $dir!</p>";
    } else {
        echo "<p style='color: green;'><strong>✓ SAFE:</strong> Cannot create directory $dir</p>";
    }
}

// Test 5: Try to delete files
echo "<h2>File Deletion Attacks (SHOULD FAIL)</h2>";
$target_files = [
    '../important_file.txt',
    '/etc/passwd',
    '/root/.bashrc',
];

foreach ($target_files as $file) {
    if (file_exists($file)) {
        $result = @unlink($file);
        if ($result) {
            echo "<p style='color: red;'><strong>✗ BREACH:</strong> Successfully deleted $file!</p>";
        } else {
            echo "<p style='color: green;'><strong>✓ SAFE:</strong> Cannot delete file $file</p>";
        }
    }
}

// Test 6: Check open_basedir
echo "<h2>PHP Configuration Security</h2>";
$open_basedir = ini_get('open_basedir');
if ($open_basedir) {
    echo "<p><strong>open_basedir is set to:</strong> $open_basedir</p>";
    echo "<p style='color: green;'><strong>✓ GOOD:</strong> open_basedir restricts file access</p>";
} else {
    echo "<p style='color: orange;'><strong>⚠ Note:</strong> open_basedir is not configured</p>";
}

// Test 7: Check disabled functions
echo "<h2>Disabled PHP Functions</h2>";
$dangerous_functions = ['exec', 'shell_exec', 'system', 'passthru', 'proc_open'];
$disabled = ini_get('disable_functions');
if ($disabled) {
    echo "<p><strong>Disabled functions:</strong> " . htmlspecialchars($disabled) . "</p>";
} else {
    echo "<p style='color: orange;'><strong>⚠ Note:</strong> No PHP functions are explicitly disabled</p>";
}
?>
