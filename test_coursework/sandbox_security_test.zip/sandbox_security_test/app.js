function testSandbox() {
    const tests = [
        'attack.php',
        'shell.php',
        'env.php',
        'sql_inject.php',
        'traverse.php',
        'write.php'
    ];
    
    const results = document.getElementById('testResults');
    if (!results) {
        const resultsDiv = document.createElement('div');
        resultsDiv.id = 'testResults';
        resultsDiv.style.marginTop = '20px';
        resultsDiv.style.padding = '15px';
        resultsDiv.style.backgroundColor = '#f0f0f0';
        resultsDiv.style.borderRadius = '4px';
        document.querySelector('.container').appendChild(resultsDiv);
    }
    
    console.log('Security tests initiated. Check PHP files for sandbox escape attempts.');
    alert('Security tests initiated. Check the server logs and PHP output for results.');
}

document.addEventListener('DOMContentLoaded', function() {
    console.log('Sandbox Security Test Page Loaded');
    console.log('Attempting to probe sandbox isolation...');
});
