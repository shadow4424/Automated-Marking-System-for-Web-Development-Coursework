<?php
/**
 * SECURITY TEST: Attempt command execution on host
 * 
 * If the sandbox is working:
 * - Commands should execute only within the container
 * - Should NOT be able to run arbitrary host commands
 */

echo "<h1>Test 2: Command Execution Attempts</h1>";

$commands = [
    'whoami'  => 'Current user',
    'id'      => 'User ID info',
    'hostname' => 'Host machine name',
    'uname -a' => 'System information',
    'pwd'     => 'Current directory',
    'ls /' => 'Root directory listing',
    'cat /etc/os-release' => 'OS release info'
];

foreach ($commands as $cmd => $description) {
    echo "<h2>$description: `$cmd`</h2>";
    
    // Try exec
    $output = [];
    $return = 0;
    @exec($cmd, $output, $return);
    
    if (!empty($output)) {
        echo "<p><strong>Exec output:</strong></p>";
        echo "<pre>" . htmlspecialchars(implode("\n", $output)) . "</pre>";
    }
    
    // Try shell_exec
    $shell_output = @shell_exec($cmd);
    if ($shell_output) {
        echo "<p><strong>Shell_exec output:</strong></p>";
        echo "<pre>" . htmlspecialchars($shell_output) . "</pre>";
    }
    
    // Try passthru
    if (function_exists('passthru')) {
        echo "<p><strong>Passthru output:</strong></p>";
        @passthru($cmd);
    }
    
    // Try system
    if (function_exists('system')) {
        echo "<p><strong>System function output:</strong></p>";
        @system($cmd);
    }
}

// Try to access /proc on host
echo "<h2>Host Process Information (/proc access)</h2>";
if (is_dir('/proc')) {
    $files = @scandir('/proc');
    if ($files !== false) {
        echo "<p>Host /proc is accessible! Found files: " . count($files) . "</p>";
        echo "<pre>" . htmlspecialchars(implode(", ", array_slice($files, 0, 10))) . "</pre>";
    } else {
        echo "<p style='color: green;'><strong>✓ SAFE:</strong> /proc is not accessible</p>";
    }
} else {
    echo "<p style='color: green;'><strong>✓ SAFE:</strong> /proc directory not found</p>";
}
?>
