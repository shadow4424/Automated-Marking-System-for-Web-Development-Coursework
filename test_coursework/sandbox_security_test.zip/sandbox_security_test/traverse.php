<?php
/**
 * SECURITY TEST: Directory Traversal / Path Traversal
 * 
 * If the sandbox is working:
 * - Should NOT be able to read files outside submission directory
 * - Should NOT be able to traverse to parent directories
 */

echo "<h1>Test 5: Directory Traversal Attempts</h1>";

$traversal_targets = [
    '../index.html',
    '../../index.html',
    '../../../etc/passwd',
    '..\\..\\..\\etc\\passwd',  // Windows-style
    '/etc/passwd',
    '/../../../etc/passwd',
    'files/../../../../etc/passwd',
    '../../../Windows/System32/drivers/etc/hosts',  // Windows
    '/proc/self/environ',
    '/proc/1/environ',
    '/proc/cmdline',
    '../run_history.json',
    '../../ams_web_runs/runid/report.json',
];

echo "<p>Attempting to read " . count($traversal_targets) . " out-of-bounds files...</p>";

foreach ($traversal_targets as $target) {
    $status = "✓ SAFE";
    $color = "green";
    
    if (file_exists($target)) {
        $status = "✗ BREACH";
        $color = "red";
        $readable = is_readable($target);
        echo "<p style='color: $color;'><strong>$status:</strong> $target exists and " . ($readable ? "is readable" : "not readable") . "</p>";
        
        if ($readable) {
            $content = file_get_contents($target);
            echo "<pre>" . htmlspecialchars(substr($content, 0, 200)) . "</pre>";
        }
    } else {
        echo "<p style='color: $color;'><strong>$status:</strong> $target not accessible</p>";
    }
}

// Try glob patterns
echo "<h2>Glob Pattern Traversal</h2>";
$globs = [
    '../*',
    '../../*',
    '/etc/*',
    '/root/*',
    '/home/*',
];

foreach ($globs as $glob) {
    $results = @glob($glob);
    if ($results && count($results) > 0) {
        echo "<p style='color: red;'><strong>✗ BREACH:</strong> Glob($glob) returned " . count($results) . " results</p>";
    }
}
?>
