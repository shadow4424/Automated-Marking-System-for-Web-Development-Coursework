<?php
/**
 * SECURITY TEST: SQL Injection attempt (simulated)
 * 
 * This demonstrates vulnerable code patterns that the assessor should catch.
 */

echo "<h1>Test 4: SQL Injection Vulnerabilities</h1>";

// Vulnerable code pattern 1: Direct concatenation
$user_input = "' OR '1'='1";
$vulnerable_query = "SELECT * FROM users WHERE name = '$user_input'";
echo "<h2>Vulnerable Pattern 1: Direct Concatenation</h2>";
echo "<p><strong>Query:</strong> " . htmlspecialchars($vulnerable_query) . "</p>";
echo "<p><span style='color: red;'><strong>⚠ VULNERABLE:</strong> This would return all users!</span></p>";

// Vulnerable code pattern 2: Loose string comparison
$password = "password123";
if ($_GET['pass'] == $password) {
    echo "<p>Login successful</p>";
}
echo "<h2>Vulnerable Pattern 2: Weak Password Comparison</h2>";
echo "<p><span style='color: red;'><strong>⚠ VULNERABLE:</strong> Type juggling could bypass this</span></p>";

// Vulnerable code pattern 3: Eval
echo "<h2>Vulnerable Pattern 3: Eval Usage</h2>";
echo "<p><span style='color: red;'><strong>⚠ VULNERABLE:</strong> eval() is extremely dangerous</span></p>";

// Vulnerable code pattern 4: Unvalidated redirect
if (isset($_GET['redirect'])) {
    $redirect = $_GET['redirect'];
    echo "<p>Redirecting to: " . htmlspecialchars($redirect) . "</p>";
}

// Vulnerable code pattern 5: File inclusion
echo "<h2>Vulnerable Pattern 5: File Inclusion</h2>";
if (isset($_GET['file'])) {
    $file = $_GET['file'];
    // This SHOULD fail due to sandbox restrictions
    $content = @file_get_contents($file);
    if ($content) {
        echo "<p>File content: " . htmlspecialchars($content) . "</p>";
    } else {
        echo "<p style='color: green;'><strong>✓ SAFE:</strong> File inclusion blocked</p>";
    }
}
?>
