<?php
/**
 * SECURITY TEST: Attempt to access host environment variables
 * 
 * If the sandbox is working:
 * - Should only see container environment variables
 * - Should NOT leak host secrets
 */

echo "<h1>Test 3: Host Environment Variables</h1>";

if (function_exists('getenv')) {
    $env = getenv();
    echo "<h2>Environment Variables via getenv()</h2>";
    echo "<p>Found " . count($env) . " environment variables</p>";
    
    $sensitive = ['PATH', 'HOME', 'USER', 'HOSTNAME', 'AWS_', 'DATABASE_', 'SECRET_', 'API_key'];
    foreach ($sensitive as $pattern) {
        foreach ($env as $key => $value) {
            if (stripos($key, $pattern) !== false) {
                echo "<p><strong>$key:</strong> " . htmlspecialchars($value) . "</p>";
            }
        }
    }
}

echo "<h2>Environment Variables via \$_ENV</h2>";
if (!empty($_ENV)) {
    foreach ($_ENV as $key => $value) {
        echo "<p><strong>$key:</strong> " . htmlspecialchars($value) . "</p>";
    }
}

echo "<h2>Environment Variables via \$_SERVER</h2>";
$server_keys = ['PATH', 'DB_HOST', 'DB_PASSWORD', 'API_KEY', 'SECRET_KEY', 'HOME', 'USER'];
foreach ($server_keys as $key) {
    if (isset($_SERVER[$key])) {
        echo "<p><strong>$_SERVER[$key]:</strong> " . htmlspecialchars($_SERVER[$key]) . "</p>";
    }
}

// Try to read .env files
echo "<h2>Looking for .env files</h2>";
$env_paths = ['../.env', '../../.env', '../../../.env', '/root/.env', '~/.env'];
foreach ($env_paths as $path) {
    if (file_exists($path)) {
        echo "<p style='color: red;'><strong>✗ FOUND:</strong> $path exists!</p>";
        $content = @file_get_contents($path);
        if ($content) {
            echo "<pre>" . htmlspecialchars($content) . "</pre>";
        }
    }
}
?>
