// Perfect Student - Valid JavaScript with required elements

/**
 * Calculate the total cost including tax
 * @param {number[]} items - Array of item prices
 * @param {number} taxRate - Tax rate as decimal (e.g., 0.1 for 10%)
 * @returns {number} Total cost including tax
 */
function calculateTotal(items, taxRate = 0.1) {
    let subtotal = 0;

    // Loop through items to calculate subtotal
    for (let i = 0; i < items.length; i++) {
        subtotal += items[i];
    }

    const tax = subtotal * taxRate;
    const total = subtotal + tax;

    return Math.round(total * 100) / 100; // Round to 2 decimal places
}

/**
 * Validate email format
 * @param {string} email - Email to validate
 * @returns {boolean} Whether email is valid
 */
function validateEmail(email) {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
}

/**
 * Display a success message
 * @param {string} message - Message to display
 */
function showMessage(message, isError = false) {
    const div = document.createElement('div');
    div.className = isError ? 'alert error' : 'alert success';
    div.textContent = message;
    document.body.insertBefore(div, document.body.firstChild);

    // Remove after 3 seconds
    setTimeout(() => div.remove(), 3000);
}

// Wait for DOM to load
document.addEventListener('DOMContentLoaded', function () {
    const contactForm = document.getElementById('contactForm');

    if (contactForm) {
        // Event listener for form submission
        contactForm.addEventListener('submit', function (event) {
            event.preventDefault();

            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const message = document.getElementById('message').value.trim();

            // Validation
            if (!name || !email || !message) {
                showMessage('Please fill in all fields.', true);
                return;
            }

            if (!validateEmail(email)) {
                showMessage('Please enter a valid email address.', true);
                return;
            }

            // Success
            showMessage('Thank you for your message! We will get back to you soon.');
            contactForm.reset();
        });
    }

    // Example usage of calculateTotal
    const cartItems = [19.99, 24.99, 9.99];
    const total = calculateTotal(cartItems, 0.08);
    console.log('Cart total:', total);
});

// Navigation smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth'
            });
        }
    });
});
