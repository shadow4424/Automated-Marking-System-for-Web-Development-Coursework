-- Perfect Student Database Schema
-- Demonstrates proper SQL design with constraints and indexes

-- Create database
CREATE DATABASE IF NOT EXISTS portfolio_db
CHARACTER SET utf8mb4
COLLATE utf8mb4_unicode_ci;

USE portfolio_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_email (email),
    INDEX idx_username (username)
);

-- Messages table (for contact form)
CREATE TABLE IF NOT EXISTS messages (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_created (created_at),
    INDEX idx_is_read (is_read)
);

-- Portfolio projects table
CREATE TABLE IF NOT EXISTS projects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    project_url VARCHAR(500),
    technologies JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user (user_id)
);

-- Insert sample data
INSERT INTO users (username, email, password_hash) VALUES
('perfect_student', 'student@example.com', '$2y$10$abcdefghijklmnopqrstuv');

INSERT INTO projects (user_id, title, description, technologies) VALUES
(1, 'Portfolio Website', 'A responsive portfolio website', '["HTML", "CSS", "JavaScript"]'),
(1, 'Task Manager', 'A full-stack task management app', '["PHP", "MySQL", "JavaScript"]');

-- Useful queries
-- Get all unread messages
SELECT * FROM messages WHERE is_read = FALSE ORDER BY created_at DESC;

-- Get user with their projects
SELECT u.username, p.title, p.description 
FROM users u 
LEFT JOIN projects p ON u.id = p.user_id 
WHERE u.id = 1;
