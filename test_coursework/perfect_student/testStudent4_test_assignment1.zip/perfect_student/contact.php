<?php
/**
 * Perfect Student - Contact Form Handler
 * Demonstrates proper PHP form handling and database interaction
 */

// Configuration
define('DB_HOST', 'localhost');
define('DB_NAME', 'portfolio_db');
define('DB_USER', 'root');
define('DB_PASS', '');

// Security headers
header('Content-Type: application/json');
header('X-Content-Type-Options: nosniff');

/**
 * Sanitize user input
 * @param string $data Raw input
 * @return string Sanitized input
 */
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Validate email format
 * @param string $email Email to validate
 * @return bool Whether email is valid
 */
function validate_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
}

/**
 * Get database connection using PDO
 * @return PDO Database connection
 */
function get_db_connection() {
    try {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
        $options = [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ];
        return new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        error_log("Database connection failed: " . $e->getMessage());
        return null;
    }
}

/**
 * Save contact message to database
 * @param string $name Sender name
 * @param string $email Sender email
 * @param string $message Message content
 * @return bool Success status
 */
function save_message($name, $email, $message) {
    $db = get_db_connection();
    if (!$db) {
        return false;
    }
    
    try {
        $stmt = $db->prepare("INSERT INTO messages (name, email, message, created_at) VALUES (?, ?, ?, NOW())");
        return $stmt->execute([$name, $email, $message]);
    } catch (PDOException $e) {
        error_log("Failed to save message: " . $e->getMessage());
        return false;
    }
}

// Handle POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $response = ['success' => false, 'message' => ''];
    
    // Get and sanitize input
    $name = isset($_POST['name']) ? sanitize_input($_POST['name']) : '';
    $email = isset($_POST['email']) ? sanitize_input($_POST['email']) : '';
    $message = isset($_POST['message']) ? sanitize_input($_POST['message']) : '';
    
    // Validation
    if (empty($name) || empty($email) || empty($message)) {
        $response['message'] = 'All fields are required.';
    } elseif (!validate_email($email)) {
        $response['message'] = 'Please enter a valid email address.';
    } elseif (strlen($message) < 10) {
        $response['message'] = 'Message must be at least 10 characters.';
    } else {
        // Save to database
        if (save_message($name, $email, $message)) {
            $response['success'] = true;
            $response['message'] = 'Thank you for your message!';
        } else {
            $response['message'] = 'Failed to save message. Please try again.';
        }
    }
    
    echo json_encode($response);
    exit;
}

// Invalid request method
http_response_code(405);
echo json_encode(['error' => 'Method not allowed']);
